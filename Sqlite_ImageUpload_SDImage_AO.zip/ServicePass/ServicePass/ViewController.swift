//
//  ViewController.swift
//  ServicePass
//
//  Created by Kaira NewMac on 7/14/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage
import AlamofireObjectMapper
import ObjectMapper

class ViewController: UIViewController {

    @IBOutlet weak var img: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnClick(_ sender: Any) {
     
        /*
        {
            "Slug": "mytesting",
            "Key": "SiteAppkey",
            "Token": "",
            "Data": {
                "IsSubscribeToFcmTopic": "false",
                "Platform": "I",
                "DeviceId": "dMxO5Ol2OJo:APA91bGhLO5iXXNkKGFVawjbuTayJg-xkgM16ffm5er_URQE80uIeiZwhmQaysTpEy9k43rScLm1l4dTddvaaIoIemr4c9YCIijrexE4H5PWtLGk_vikBYYB2oV713YUnKPIhrhbl2Vv"
            }
        }
        */
        
        let parameters: Parameters = ["Slug": "mitun",
                                    "Key": "SiteAppkey",
                                    "Token": "",
                                    "Data": [
                                        "IsSubscribeToFcmTopic": "false",
                                        "Platform": "I",
                                        "DeviceId": ""]]
        request(ServiceUrl.Splash, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: nil).responseJSON { (response) in
            print(response)
            if response.result.isSuccess == true {
                
                let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?

                let serviceResponse = Mapper<ServiceResponse<SplashGetModel<FirmAndSiteDetail<OwnerNamePhoneNumberList>,SiteImages,SiteLabels,Categories<SubCategories>,FontDetails,SellDetails,StateList,SiteColors>>>().map(JSONString: datastring!)
                print(serviceResponse)
                
                if serviceResponse?.IsSuccess == true {
                    DBHelper.InsertServiceResponse(strQuery: DBQuery().inserData(strValue: (datastring!)))
                }
            } else {
                print(response.result.error?.localizedDescription as Any)
            }
        }
    }
    
    @IBAction func UploadImage() {
        upload(multipartFormData: { (multipartFormData) in
            
            var imageData: [Data] = []
            
            let imageData1 = UIImageJPEGRepresentation(UIImage(named: "8-Dashborad -1")!, 1.0) as! Data
            imageData.append(imageData1)
            
            var parameter : NSDictionary = NSDictionary()
            parameter = ["UserID":"78"
                           ,"Token":"7e513f04-66ba-400f-9343-72ea1fa449db"
                           ,"ProductImageID":"0"
                           ,"Key":"SiteAdminAppkey"] as [String:String] as NSDictionary
            
            multipartFormData.append(imageData1 as Data, withName: "photo_path", fileName: "uploaded_file.jpeg", mimeType: "image/jpeg")
            
            for (key, value) in parameter {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String )
            }
            
            //  print("mutlipart 2st \(multipartFormData)")
        }, to:ServiceUrl.UploadProductImage)
        { (result) in
            switch result {
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (Progress) in
                    //                            if let view = uiviewController as? RegistrationVC {
                    //                                view.imgProgress.isHidden = false
                    //                                view.imgProgress.setProgress(Float(Progress.fractionCompleted), animated: true)
                    //                            }
                    
                })
                upload.responseJSON { response in
                    //self.delegate?.showSuccessAlert()
                    
                    //                            if let view = uiviewController as? RegistrationVC {
                    //                                view.imgProfile.alpha = 1
                    //                                view.imgProgress.isHidden = true
                    //                                view.imgProgress.progress = 0.0
                    //                            }
                    
                    if(response.result.isSuccess){
                        
                        let datastring = NSString(data:response.data!, encoding:String.Encoding.utf8.rawValue) as String?
                        
                        let serviceResponse = Mapper<ServiceResponseArray<ProductImageModel>>().map(JSONString: datastring!)
                        self.setImage(strURL: (serviceResponse?.Data?[0].FullImagePath)!)
                        
                    }
                }
            case .failure(let encodingError):
                //self.delegate?.showFailAlert()
                print(encodingError)
            }
        }
    }
    
    func setImage(strURL:String){
        img.setIndicatorStyle(.white)
        img.setShowActivityIndicator(true)
        img.setIndicatorStyle(.white)
        img.setShowActivityIndicator(true)
        img.sd_setImage(with: URL(string: (strURL)), placeholderImage: UIImage(named: "ic_Placeholder_Post"))
    }

}


class ServiceUrl
{
    
    static let Domain = "http://mitun.morecustomersapp.com" //Mitun
    
    /******************************Domain Concact************************/
    
    static let Base = Domain + "/siteapp/api/" //Live URL
    
    
    //Home Service Call
    static let Home                     = Base + "/homeapi/GetHomePageDetail"
    static let Splash                   = Base + "/homeapi/GetSplashScreenDetail"               // to get Splash Screen Details
    static let UploadProductImage       = Base + "/SiteAdminProduct/AddProductImages"                    // to Upload Product Images
}



struct DBParameter {
    
    ///MARK: - SqlLite DatabseName
    static let DBName = "Data"
    
}


struct DBTableName {
    
    //Contact Table
    static let Contact                          = "Contact"
    static let Activities                       = "Activities"
    static let ActivityType                     = "ActivityType"
    static let OutComeType                      = "OutComeType"
    static let SuggestedProduct                 = "Deal"
    static let SuggestedProductCollection       = "DealCollection"
    static let Product                          = "Product"
    static let CallLogs                         = "CallLogs"
    static let Goal                            = "Goal"
    static let GoalType                        = "GoalType"
    static let EmailDetail                   = "EmailDetail"
    static let Response                   = "Response"
    
}

// MARK: - SQL Query
struct DBQuery {
    
    func inserData(strValue:String) -> String{
        return "insert into \(DBTableName.Response) (ResponseData) values ('\(strValue)')"
    }
    
    /*
     "select D.*,P.* FROM \(DBTableName.SuggestedProductCollection) D  inner join \(DBTableName.SuggestedProduct) P on D.DealId = P.DealId where D.UserId = \(objDeal.UserId!) AND EndDate >= \(from) AND EndDate <= \(to) ORDER BY D.DealId DESC"
     
     select = "Select c.Name,c.ContactId,c.UserId,c.WebContactId,c.Phone1,c.Phone2,c.EmailHome,c.EmailWork,A.ActivityId, A.Description, A.CreatedDate, A.ModifiedDate FROM Contact C LEFT JOIN Activities AS A ON C.ContactId = A.ContactId WHERE (('\(searchValue.trimingString())' IS NULL) OR ((A.Description LIKE '\(searchValue.trimingString())') OR (C.Name  LIKE '\(searchValue.trimingString())') OR (C.Phone1  LIKE '\(searchValue.trimingString())') OR (C.Phone2  LIKE '\(searchValue.trimingString())') OR (C.EmailHome LIKE '\(searchValue.trimingString())') OR (C.EmailWork LIKE '\(searchValue.trimingString())')))"
     
     "UPDATE \(DBParameter.TblNote) SET NotesDesc=\"\(objNote.NotesDesc!)\", ModifiedDate=\"\(objNote.ModifiedDate!)\",IsUpdate=\"\(objNote.IsUpdate!)\" WHERE NotesId=\"\(objNote.NotesId!)\""
     
     "Delete FROM \(DBParameter.TblTask) WHERE TaskId = \(objTask.TaskId!)"
     
     "insert into \(DBParameter.TblNote) (ContactId, WebNotesId, UserId, NotesDesc, CreatedDate, CreatedBy, ModifiedDate,IsUpdate) values(\"\(objNote.ContactId!)\",\"\(objNote.WebNotesId!)\",\"\(objNote.UserId!)\",\"\(objNote.NotesDesc!)\",\"\(objNote.CreatedDate!)\",\"\(objNote.CreatedBy!)\",\"\(objNote.ModifiedDate!)\",\"\(objNote.IsUpdate!)\")"
     
     */
    
}
