//
//  ServicePass-BridgingHeader.h
//  ServicePass
//
//  Created by Kaira NewMac on 7/14/17.
//  Copyright © 2017 Kaira NewMac. All rights reserved.
//

#ifndef ServicePass_BridgingHeader_h
#define ServicePass_BridgingHeader_h

#import <sqlite3.h>

#endif /* ServicePass_BridgingHeader_h */
